"""
===============================================================================
Module: History & Notifications (history.py)
Description: 
    Manages the persistence of generated analytical pipelines (Projects) 
    to MongoDB. Provides endpoints to save, list, and reload previous 
    projects. Integrates with the Resend API via FastAPI BackgroundTasks 
    to dispatch asynchronous email notifications upon project completion.
===============================================================================
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Any
from datetime import datetime
import logging
import os
import motor.motor_asyncio
import resend
import urllib.parse

# Ligação à Base de Dados
MONGO_URL = os.getenv("MONGO_URL", "mongodb://pipeline_mongo:27017")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
db = client.pipeline_db 

logger = logging.getLogger("pipeline_api")
router = APIRouter(prefix="/history", tags=["History & Emails"])

class SaveProjectRequest(BaseModel):
    email: str = "admin@beneutral.pt"
    project_name: str
    pipeline_data: Any

# 1. FUNÇÃO DE ENVIO DE EMAIL (A correr em Background)
def send_email_task(receiver_email: str, project_name: str, save_time: str):
    resend.api_key = os.getenv("RESEND_API_KEY", "re_tua_chave_aqui")
    
    if not resend.api_key or resend.api_key == "re_tua_chave_aqui":
        logger.warning("RESEND_API_KEY não configurada. Simulação de envio de email.")
        return

    try:
        email_params = {
            "from": "Be.Neutral Pipeline <onboarding@resend.dev>",
            "to": ["luispedrobaptista0@gmail.com"], # O TEU EMAIL DE DESTINO AQUI!
            "subject": f"Be.Neutral - Project '{project_name}' Saved!",
            "html": f"""
            <h3>Congratulations!</h3>
            <p>Your Analytical Pipeline project <strong>"{project_name}"</strong> has been successfully finalized and saved on {save_time}.</p>
            <p>You can log in to the Be.Neutral dashboard at any time to review your Data Warehouse models and Analytical Dashboards.</p>
            <br/>
            <p>Best regards,<br/><strong>Be.Neutral AI Pipeline</strong></p>
            """
        }
        email = resend.Emails.send(email_params)
        logger.info(f"Email successfully sent via Resend to luispedrobaptista0@gmail.com. ID: {email.get('id')}")
    except Exception as e:
        logger.error(f"Failed to send email via Resend: {str(e)}")

# 2. GRAVAR PROJETO NA BASE DE DADOS
@router.post("/save")
async def save_project(req: SaveProjectRequest, background_tasks: BackgroundTasks):
    try:
        now = datetime.now()
        # Usamos hífens nos projetos novos para os links ficarem bonitos
        time_str = now.strftime("%d-%m-%Y %H:%M")
        unique_name = f"{req.project_name} ({time_str})"

        project_doc = {
            "email": req.email,
            "project_name": unique_name,
            "created_at": now,
            "pipeline_data": req.pipeline_data
        }
        
        await db.projects.insert_one(project_doc)
        
        # Dispara o envio do email em segundo plano mal tu guardes!
        background_tasks.add_task(send_email_task, req.email, req.project_name, time_str)

        return {"status": "success", "message": "Project saved successfully."}
    except Exception as e:
        logger.error(f"Erro ao guardar projeto: {str(e)}")
        raise HTTPException(status_code=500, detail="Database error while saving.")

# 3. LISTAR PROJETOS DO UTILIZADOR
@router.get("/list/{email}")
async def list_projects(email: str):
    try:
        cursor = db.projects.find({"email": email}, {"pipeline_data": 0}).sort("created_at", -1)
        projects = await cursor.to_list(length=100)
        for p in projects: p["_id"] = str(p["_id"])
        return {"status": "success", "projects": projects}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 4. CARREGAR UM PROJETO ESPECÍFICO (A MAGIA ANTI-ERRO 500 ESTÁ AQUI)
@router.get("/load/{full_path:path}")
async def load_project(full_path: str):
    try:
        # Lê o link todo (ex: "N (04/04/2026 15:15)/admin@beneutral.pt")
        # O rsplit('/', 1) corta a frase apenas na ÚLTIMA barra que encontrar
        parts = full_path.rsplit('/', 1)
        
        if len(parts) != 2:
            raise HTTPException(status_code=400, detail="Formato de rota inválido.")
            
        project_name = parts[0]
        email = parts[1]

        project = await db.projects.find_one({"email": email, "project_name": project_name})
        if not project:
            raise HTTPException(status_code=404, detail="Project not found.")
            
        project["_id"] = str(project["_id"])
        return {"status": "success", "project": project}
    except Exception as e:
        logger.error(f"Erro ao carregar projeto: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
# 5. APAGAR UM PROJETO
@router.delete("/delete/{full_path:path}")
async def delete_project(full_path: str):
    try:
        parts = full_path.rsplit('/', 1)
        if len(parts) != 2:
            raise HTTPException(status_code=400, detail="Formato de rota inválido.")
        
        # Descodifica a URL para o nome original com espaços e parênteses
        project_name = urllib.parse.unquote(parts[0])
        email = urllib.parse.unquote(parts[1])

        result = await db.projects.delete_one({"project_name": project_name, "email": email})
        if result.deleted_count == 1:
            return {"status": "success", "message": "Projeto apagado com sucesso."}
        else:
            raise HTTPException(status_code=404, detail="Projeto não encontrado.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))