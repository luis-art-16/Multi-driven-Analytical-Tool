"""
===============================================================================
Module: Requirements Structuring and Refinement (rsr.py)
Description: 
    Entry point for the Requirements-Driven pathway. Processes natural language 
    business requirements and translates them into a formal Goal-Oriented 
    i* framework model. Classifies requirements into Strategic Goals, Decision 
    Goals, Information Goals, and Tasks, assigning MoSCoW prioritization.
===============================================================================
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import json
import re
from services.mistral_client import call_mistral_api

router = APIRouter(prefix="/rsr", tags=["RSR"])

class RsrRequest(BaseModel):
    input_text: str
    temperature: float = 0.2

# Função à prova de balas para limpar o output da LLM (remove Markdown e texto extra)
def extract_json(response: str):
    try:
        if "```" in response:
            blocks = response.split("```")
            for block in blocks:
                if "{" in block or "[" in block:
                    block = block.replace("json\n", "", 1).strip()
                    return json.loads(block)
        
        match = re.search(r'(\{.*\}|\[.*\])', response, re.DOTALL)
        if match:
            return json.loads(match.group(1))
            
        return json.loads(response)
    except Exception as e:
        raise ValueError(f"Failed to parse JSON. Error: {e}")

def build_istar_prompt(input_text: str) -> str:
    return f"""You are an expert Requirements Engineer using the i* framework for Data Warehousing.
    Analyze the following analytical requirements:
    {input_text}

    CRITICAL RULES:
    1. Identify the Main Actor (e.g., Manager, User) and the Target System.
    2. Decompose the request mapping to these specific types, enforcing a STRICT 4-LEVEL HIERARCHY:
       - Level 1: "Strategic Goal" (Highest level objectives)
       - Level 2: "Decision Goal" (Questions to answer / Decisions to make to achieve the SG)
       - Level 3: "Information Goal" (Specific data needed to support the DG)
       - Level 4: "Task" (Actionable steps or calculations to fulfill the IG)
    3. HIERARCHY LINKING: The elements MUST be strictly linked. A Decision Goal descends from a Strategic Goal. An Information Goal descends from a Decision Goal. A Task descends from an Information Goal. Do not skip levels.
    4. You MUST include a "parent" field in each dependency containing the exact "dependum" string of its parent. For Strategic Goals, "parent" is null.
    5. You MUST assign a "priority" to every dependency using the MoSCoW method: "Must have", "Should have", or "Could have".
    6. ALL OUTPUT TEXT MUST BE IN STRICT ENGLISH.

    Return ONLY a valid JSON with "actors" and "dependencies".
    Format:
    {{
      "actors": [
        {{"id": "a1", "name": "Decision-maker", "type": "Role"}}
      ],
      "dependencies": [
        {{
          "id": "SG1",
          "depender": "Decision-maker", 
          "dependee": "System", 
          "dependum": "Reduce Energy Consumption", 
          "type": "Strategic Goal",
          "priority": "Must have",
          "parent": null
        }},
        {{
          "id": "DG1",
          "depender": "Decision-maker", 
          "dependee": "System", 
          "dependum": "Which machines consume the most energy?", 
          "type": "Decision Goal",
          "priority": "Must have",
          "parent": "Reduce Energy Consumption"
        }},
        {{
          "id": "IG1",
          "depender": "Decision-maker", 
          "dependee": "System", 
          "dependum": "Energy consumption per machine", 
          "type": "Information Goal",
          "priority": "Must have",
          "parent": "Which machines consume the most energy?"
        }},
        {{
          "id": "T1",
          "depender": "Decision-maker", 
          "dependee": "System", 
          "dependum": "Calculate total kWh per machine ID", 
          "type": "Task",
          "priority": "Must have",
          "parent": "Energy consumption per machine"
        }}
      ]
    }}"""
    
@router.post("/generate")
async def generate_rsr(req: RsrRequest):
    prompt = build_istar_prompt(req.input_text)
    try:
        response = await call_mistral_api(prompt, req.temperature)
        data = extract_json(response)
        
        # Validação extra de segurança: Se a IA não gerou dependências, criamos um array vazio
        if "dependencies" not in data:
            data["dependencies"] = []
            
        return {"status": "success", "istar_model": data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno ao processar o RSR: {str(e)}")