"""
===============================================================================
Module: Mistral AI API Client (mistral_client.py)
Description: 
    Provides a unified, globally accessible client for the Mistral AI API.
    Configured with an extended timeout (5 minutes) to accommodate complex, 
    long-running LLM generation tasks such as analytical modeling and 
    JSON schema structuring.
===============================================================================
"""

import logging
from mistralai.client import MistralClient
from mistralai.models.chat_completion import ChatMessage
from core.config import settings

logger = logging.getLogger("pipeline_api")

# Client configurado com timeout para evitar interrupções a meio da geração
client = MistralClient(api_key=settings.MISTRAL_API_KEY, timeout=300.0)

async def call_mistral_api(prompt: str, temperature: float = None, model: str = None) -> str:
    """
    Universal function to call Mistral AI at any stage of the project.
    """
    temp = temperature if temperature is not None else settings.MISTRAL_TEMPERATURE_DEFAULT
    selected_model = model or settings.MISTRAL_MODEL
    
    logger.info(f"Calling Mistral API (Model: {selected_model}, Temp: {temp})")
    
    try:
        messages = [
            ChatMessage(role="system", content="You are a senior data architect and requirements engineer."),
            ChatMessage(role="user", content=prompt)
        ]
        
        response = client.chat(
            model=selected_model,
            messages=messages,
            temperature=temp
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logger.error(f"Error in Mistral API: {str(e)}")
        raise e