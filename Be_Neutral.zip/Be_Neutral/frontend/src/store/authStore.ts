/**
 * ============================================================================
 * Module: Authentication Store (authStore.ts)
 * Description: 
 * Manages the user session state using Zustand. In this prototype version, 
 * authentication constraints are bypassed, providing a default administrator 
 * context ("admin@beneutral.pt") to facilitate uninterrupted evaluation 
 * of the main analytical pipeline methodology.
 * ============================================================================
 */

import { create } from 'zustand';

interface AuthState {
  user: { name: string; email: string } | null;
  isAuthenticated: boolean;
  logout: () => void;
  restoreSession: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  // Define o utilizador padrão para efeitos de protótipo e histórico
  user: { name: "Be.Neutral Admin", email: "admin@beneutral.pt" },
  isAuthenticated: true,

  logout: () => {
    // Num sistema de login real, isto limparia o LocalStorage e o estado
    set({ user: null, isAuthenticated: false });
    // Como é protótipo, voltamos a injetar o Admin após o refresh da página
    window.location.reload(); 
  },

  restoreSession: async () => {
    // Garante que a plataforma tem sempre um utilizador ativo
    set({ 
      user: { name: "Be.Neutral Admin", email: "admin@beneutral.pt" }, 
      isAuthenticated: true 
    });
  }
}));