/**
 * ============================================================================
 * Configuration: Vite Build Tool
 * Description: 
 * Configures the React development server, including host exposure for 
 * Docker containerization and polling for hot-module replacement (HMR) 
 * in virtualized environments.
 * ============================================================================
 */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: true, // Necessário para o Docker expor a porta
    port: 5173,
    watch: {
      usePolling: true, // Garante que as mudanças no código refletem no Docker
    }
  }
})